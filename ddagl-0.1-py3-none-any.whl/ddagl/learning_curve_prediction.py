import copy

import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


class SequentialRegressionModel(BaseEstimator, RegressorMixin):
    def __init__(self, base_estimator=SVR(), one_regressor_per_ts: bool = False, scaler=StandardScaler()):
        self.regressor = base_estimator
        self.is_fit = False
        self.regressors_ = None
        self.one_regressor_per_ts = one_regressor_per_ts
        self.scaler = scaler
        self.scaler_fitted_ = False

    def fit(self, X, y):
        self.scaler_fitted_ = False
        X = self.scale_features(X)
        nb_regressors = len(X[0]) if not self.one_regressor_per_ts else np.prod(np.shape(X[0]))

        self.regressors_ = [copy.deepcopy(self.regressor) for _ in range(nb_regressors)]
        for i, regressor in enumerate(self.regressors_):
            x = self._reshape_x(X, i)
            regressor.fit(x, y)
        self.is_fit = True

    def scale_features(self, x):
        feature_shape = x.shape[1:]
        x_reshaped = np.reshape(x, (len(x), np.prod(feature_shape)))
        if not self.scaler_fitted_:
            self.scaler.fit(x_reshaped)
            self.scaler_fitted_ = True
        return np.reshape(self.scaler.transform(x_reshaped), (len(x), *feature_shape))

    @staticmethod
    def _reshape_x(x, cutoff):
        x = x[:, :cutoff + 1]
        return np.reshape(x, (x.shape[0], np.product(x.shape[1:])))

    def predict(self, X):
        X = self.scale_features(X)
        predictions = [regressor.predict(self._reshape_x(X, i)) for i, regressor in enumerate(self.regressors_)]
        return np.mean(predictions, axis=0)
